const video = document.querySelector('#camera-preview');
const previewFrame = document.querySelector('#preview-frame');
const placeholder = document.querySelector('#camera-placeholder');
const placeholderTitle = document.querySelector('#placeholder-title');
const placeholderCopy = document.querySelector('#placeholder-copy');
const startButton = document.querySelector('#start-camera');
const captureButton = document.querySelector('#capture-photo');
const switchButton = document.querySelector('#switch-camera');
const stopButton = document.querySelector('#stop-camera');
const status = document.querySelector('#camera-status');
const statusText = document.querySelector('#status-text');
const liveLabel = document.querySelector('#live-label');
const resolutionLabel = document.querySelector('#preview-resolution');
const intensityInput = document.querySelector('#intensity');
const intensityValue = document.querySelector('#intensity-value');
const filterButtons = [...document.querySelectorAll('.filter-card')];
const captureFlash = document.querySelector('#capture-flash');

const filters = {
  original: () => 'none',
  golden: (amount) => `sepia(${0.42 * amount}) saturate(${1 + 0.28 * amount}) contrast(${1 + 0.04 * amount})`,
  rose: (amount) => `sepia(${0.2 * amount}) hue-rotate(${-12 * amount}deg) saturate(${1 + 0.16 * amount}) brightness(${1 + 0.025 * amount})`,
  film: (amount) => `contrast(${1 + 0.17 * amount}) saturate(${1 - 0.38 * amount}) sepia(${0.12 * amount}) brightness(${1 + 0.025 * amount})`,
  dream: (amount) => `hue-rotate(${12 * amount}deg) saturate(${1 + 0.22 * amount}) brightness(${1 + 0.07 * amount}) contrast(${1 - 0.08 * amount})`,
  mono: (amount) => `grayscale(${amount}) contrast(${1 + 0.08 * amount})`
};

let stream = null;
let facingMode = 'user';
let selectedFilter = 'original';
let captureInProgress = false;

function renderFilter() {
  const amount = Number(intensityInput.value) / 100;
  const filter = filters[selectedFilter](amount);
  video.style.filter = filter;
  intensityValue.textContent = `${intensityInput.value}%`;
  intensityInput.style.setProperty('--range-progress', `${intensityInput.value}%`);
}

function setCameraStatus(message, isOn = false) {
  statusText.textContent = message;
  status.classList.toggle('is-on', isOn);
  document.querySelector('.live-badge').classList.toggle('is-live', isOn);
  liveLabel.textContent = isOn ? 'LIVE' : 'PREVIEW';
}

function setCameraControls(isOn) {
  captureButton.disabled = !isOn;
  switchButton.disabled = !isOn;
  stopButton.disabled = !isOn;
  startButton.hidden = isOn;
}

function showCameraError(error) {
  let title = 'Could not start your camera';
  let message = 'Check your camera connection and browser permissions, then try again.';

  if (!window.isSecureContext) {
    title = 'A secure connection is needed';
    message = 'Open this page over HTTPS or on localhost to use your camera.';
  } else if (error?.name === 'NotSupportedError') {
    title = 'Camera access is not supported';
    message = 'Try opening this page in a browser that supports camera access.';
  } else if (error?.name === 'NotAllowedError' || error?.name === 'SecurityError') {
    title = 'Camera permission needed';
    message = 'Allow camera access in your browser settings, then try again.';
  } else if (error?.name === 'NotFoundError' || error?.name === 'DevicesNotFoundError') {
    title = 'No camera found';
    message = 'Connect a camera to your device and try again.';
  } else if (error?.name === 'NotReadableError' || error?.name === 'TrackStartError') {
    title = 'Camera is busy';
    message = 'Close other apps using your camera, then give it another try.';
  }

  placeholderTitle.textContent = title;
  placeholderCopy.textContent = message;
  placeholder.classList.remove('is-hidden');
  setCameraStatus('Camera unavailable');
}

async function startCamera(mode = facingMode, exactMode = false) {
  if (!navigator.mediaDevices?.getUserMedia) {
    showCameraError({ name: window.isSecureContext ? 'NotSupportedError' : 'SecurityError' });
    return false;
  }

  startButton.disabled = true;
  startButton.querySelector('span').textContent = 'Connecting…';
  setCameraStatus('Requesting access');

  let nextStream;
  try {
    nextStream = await navigator.mediaDevices.getUserMedia({
      audio: false,
      video: { facingMode: exactMode ? { exact: mode } : { ideal: mode }, width: { ideal: 1920 }, height: { ideal: 1080 } }
    });
  } catch (error) {
    startButton.disabled = false;
    startButton.querySelector('span').textContent = 'Try again';
    showCameraError(error);
    return false;
  }

  const previousStream = stream;
  stream = nextStream;
  facingMode = mode;
  video.srcObject = stream;
  try {
    await video.play();
  } catch {
    // The browser may defer playback; the stream is still available after a user gesture.
  }
  previousStream?.getTracks().forEach((track) => track.stop());

  const track = stream.getVideoTracks()[0];
  const settings = track?.getSettings?.() || {};
  resolutionLabel.textContent = settings.width && settings.height ? `${settings.width} × ${settings.height}` : 'CAMERA ON';
  placeholder.classList.add('is-hidden');
  previewFrame.classList.add('has-stream');
  setCameraControls(true);
  setCameraStatus('Camera is on', true);
  startButton.disabled = false;
  startButton.querySelector('span').textContent = 'Turn on camera';

  track?.addEventListener('ended', () => {
    if (stream?.getVideoTracks().includes(track)) stopCamera('Camera disconnected');
  }, { once: true });
  return true;
}

function stopCamera(message = 'Camera is off') {
  stream?.getTracks().forEach((track) => track.stop());
  stream = null;
  video.srcObject = null;
  previewFrame.classList.remove('has-stream');
  placeholder.classList.remove('is-hidden');
  placeholderTitle.textContent = 'Your moment starts here';
  placeholderCopy.textContent = 'Turn on your camera to see the magic.';
  resolutionLabel.textContent = 'READY WHEN YOU ARE';
  setCameraControls(false);
  startButton.disabled = false;
  startButton.querySelector('span').textContent = 'Turn on camera';
  setCameraStatus(message);
}

async function switchCamera() {
  const nextMode = facingMode === 'user' ? 'environment' : 'user';
  const previousMode = facingMode;
  const switched = await startCamera(nextMode, true);
  if (!switched && stream) {
    facingMode = previousMode;
    placeholder.classList.add('is-hidden');
    startButton.querySelector('span').textContent = 'Turn on camera';
    setCameraStatus('Could not switch camera', true);
  }
}

function capturePhoto() {
  if (!stream || video.readyState < HTMLMediaElement.HAVE_CURRENT_DATA || captureInProgress) return;
  const width = video.videoWidth;
  const height = video.videoHeight;
  if (!width || !height) return;

  captureInProgress = true;
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const context = canvas.getContext('2d');
  if (!context) {
    captureInProgress = false;
    setCameraStatus('Could not save photo', true);
    return;
  }

  context.filter = filters[selectedFilter](Number(intensityInput.value) / 100);
  if (facingMode === 'user') {
    context.translate(width, 0);
    context.scale(-1, 1);
  }
  context.drawImage(video, 0, 0, width, height);
  canvas.toBlob((blob) => {
    captureInProgress = false;
    if (!blob) {
      setCameraStatus('Could not save photo', true);
      return;
    }
    const url = URL.createObjectURL(blob);
    const download = document.createElement('a');
    download.href = url;
    download.download = `luma-${new Date().toISOString().replace(/[:.]/g, '-')}.png`;
    download.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    setCameraStatus('Photo saved', true);
    captureFlash.classList.remove('flash');
    void captureFlash.offsetWidth;
    captureFlash.classList.add('flash');
  }, 'image/png');
}

filterButtons.forEach((button) => {
  button.addEventListener('click', () => {
    selectedFilter = button.dataset.filter;
    filterButtons.forEach((item) => {
      const selected = item === button;
      item.classList.toggle('is-selected', selected);
      item.setAttribute('aria-pressed', String(selected));
    });
    const index = filterButtons.indexOf(button) + 1;
    document.querySelector('.filter-count').innerHTML = `${String(index).padStart(2, '0')} <span>/ 06</span>`;
    renderFilter();
  });
});

intensityInput.addEventListener('input', renderFilter);
startButton.addEventListener('click', () => startCamera());
captureButton.addEventListener('click', capturePhoto);
switchButton.addEventListener('click', switchCamera);
stopButton.addEventListener('click', () => stopCamera());
document.addEventListener('keydown', (event) => {
  if (event.code === 'Space' && !event.repeat && !event.target.matches('button, input, textarea, select')) {
    event.preventDefault();
    capturePhoto();
  }
});
window.addEventListener('pagehide', () => stream?.getTracks().forEach((track) => track.stop()));

renderFilter();